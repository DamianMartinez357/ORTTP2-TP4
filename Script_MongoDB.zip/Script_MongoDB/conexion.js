import { MongoClient } from "mongodb"

const cliente = new MongoClient('mongodb://localhost',{
    useNewUrlParser: true,
    useUnifiedTopology: true
})

try {
    console.log('Intentando conectar con la base de datos')
    await cliente.connect()
    console.log('Conexión exitosa')

    const bd = cliente.db('empresa')

    //Si la conexión es exitosa, representar en consola el nombre y apellido de cada uno de las
    //personas almacenadas en la colección clientes.

    let clientes = await bd.collection('clientes').find({},{nombre: 1,apellido:1}).toArray()
    console.log('Lectura exitosa')
    console.log('Listado de clientes por Nombre y Apellido:')
    console.log(clientes)

    //Luego le agregará el campo “codigo” a cada uno de los documentos almacenados en la
    //colección productos con el valor ‘xxx-xxxxx’ y posteriormente a esta operación,
    //mostrará todos los productos almacenados imprimiendo por consola el nombre, precio y
    //codigo de cada uno de ellos.

    let agregarCodigo = await bd.collection('productos').updateMany({}, {$set:{"codigo": "xxx-xxxxx"}})
    console.log('Actualización exitosa')
    console.log(agregarCodigo)

    let productos = await bd.collection('productos').find({},{nombre:1,precio:1,codigo:1}).toArray()
    console.log('Lectura exitosa')
    console.log('Listado de productos por Nombre, Precio y Código:')
    console.log(productos)

    cliente.close()
    console.log('Conexión cerrada')
}
catch(error) {
    console.log(`Conexión fallida, ocurrió el siguiente error: ${error.message}`)
}